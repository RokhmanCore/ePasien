<?php
// Copy this file to local-secrets.php on your own server.
// Never commit local-secrets.php to a public repository.
// Set EPASIEN_AES_KEY to the existing private key used by your current ePasien installation.
define('EPASIEN_AES_KEY', 'ISI_KUNCI_LAMA_DI_SERVER');
